/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package p2_si;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.ejml.simple.SimpleMatrix;
import p2_si.mnist.MnistManager;

/**
 *
 * @author fidel
 */
public class MnistLoader {
    
    void loadTrainData(SimpleMatrix x, SimpleMatrix y){
        
        try {
            //Cargo las imagenes del conjunto de entrenamiento de MNIST a una matriz Colt
            MnistManager mnistManager = new MnistManager("src/p2_si/mnist/train-images-idx3-ubyte", "src/p2_si/mnist/train-labels-idx1-ubyte");
            
            System.out.print("Cargando el conjunto de entrenamiento ");
            
            for(int i=0; i<60000; i++) {
                
                if(i%10000==0) System.out.print(".");
                
                mnistManager.setCurrent(i+1); 
                int[][] image = mnistManager.readImage();
                SimpleMatrix mimg = new SimpleMatrix(copyFromIntArray(image));
                mimg.reshape(1,784);
                x.insertIntoThis(i, 0, mimg);
                y.set(i, mnistManager.readLabel());

            }
            System.out.println();
                    
             
        } catch (IOException ex) {
            Logger.getLogger(MnistLoader.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    void loadTestData(SimpleMatrix x, SimpleMatrix y){
        
        try {
            //Cargo las imagenes del conjunto de entrenamiento de MNIST a una matriz Colt
            MnistManager mnistManager = new MnistManager("src/p2_si/mnist/t10k-images-idx3-ubyte", "src/p2_si/mnist/t10k-labels-idx1-ubyte");
            
            System.out.print("Cargando el conjunto de test ");
            
            for(int i=0; i<10000; i++) {
                
                mnistManager.setCurrent(i+1); 
                int[][] image = mnistManager.readImage();
                SimpleMatrix mimg = new SimpleMatrix(copyFromIntArray(image));
                mimg.reshape(1,784);
                x.insertIntoThis(i, 0, mimg);
                y.set(i, mnistManager.readLabel());

            }
            System.out.println();
                    
             
        } catch (IOException ex) {
            Logger.getLogger(MnistLoader.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
   
    public double[][] copyFromIntArray(int[][] source) {
        double[][] dest = new double[source.length][source[0].length];
        for(int i=0; i<source.length; i++) {
             for(int j = 0; j < source[0].length; j++)
                 dest[i][j] = (double) source[i][j];

        }
        return dest;
    }
    
    public void generateEJMLBinFiles() throws IOException{
  
        SimpleMatrix trainX = new SimpleMatrix(60000,784);
        SimpleMatrix trainY = new SimpleMatrix(60000,1);
        loadTrainData(trainX,trainY);
        trainX = trainX.transpose();
        trainX.saveToFileBinary("src/p2_si/mnist/train_x.data");
        trainY = trainY.transpose();
        trainY.saveToFileBinary("src/p2_si/mnist/train_y.data");
        
        trainX = new SimpleMatrix(10000,784);
        trainY = new SimpleMatrix(10000,1);
        loadTestData(trainX,trainY);
        trainX = trainX.transpose();
        trainX.saveToFileBinary("src/p2_si/mnist/test_x.data");
        trainY = trainY.transpose();
        trainY.saveToFileBinary("src/p2_si/mnist/test_y.data");
        
        System.out.println("Guardanto MNIST en formato binario");
        
    }
    
}
