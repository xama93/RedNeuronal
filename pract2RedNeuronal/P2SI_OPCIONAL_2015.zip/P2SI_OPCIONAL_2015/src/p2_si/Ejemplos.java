/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package p2_si;

import java.io.IOException;
import org.ejml.ops.MatrixComponent;
import org.ejml.simple.SimpleMatrix;

/**
 *
 * @author fidel
 */
public class Ejemplos {
    
    /**
     * Ejemplo de como se clasificará una imagen utilizando la red. En este caso
     * la red no se ha entrenado aún
     * @param imagenId Indice de la imagen del conjunto de entrenamiento entre 0 y 59999
     * @throws IOException 
     */
    public static void clasificarImagenEntrenamiento(int imagenId) throws IOException{
        System.out.println("Cargando MNIST...");
        
        //Cargar datos entrenamiento y test imagen 768 x 60000 
        SimpleMatrix train_x = SimpleMatrix.loadBinary("src/p2_si/mnist/train_x.data");
        //clasificación 1 x 60000
        SimpleMatrix train_y = SimpleMatrix.loadBinary("src/p2_si/mnist/train_y.data");  
        //768 x 10000 
        SimpleMatrix test_x = SimpleMatrix.loadBinary("src/p2_si/mnist/test_x.data");     
        //1 x 10000
        SimpleMatrix test_y = SimpleMatrix.loadBinary("src/p2_si/mnist/test_y.data");
               
        
        //Creo una red para clasificar imágenes de 28*28 con 100 neuronas en la
        //capa oculta y 10 en la de salida (una por digito posible)
        NNetwork mynet = new NNetwork(new int[]{28*28,100,10});
        
        
        //Obtengo la imagen en formato vectorial
        int column = imagenId;
        SimpleMatrix x = train_x.extractMatrix(0, 784,column, column+1);
        
        
        //Clasifico la imagen utilizando la NN (la red aún no está entrenadada)
        SimpleMatrix output = mynet.feedforward(x);
        output.print();
    }
    
    /** 
     * Ejemplo de como se pueden personalizar los pesos y bias de una red para 
     * poder comprobar su funcionamiento
     */
    public static void debugNN(){
        
        //Creo una red pequeña
        NNetwork mynet = new NNetwork(new int[]{3,2,4});
        
        //Personalizo los pesos y los bias
        SimpleMatrix w0 = mynet.getWeight(0);
        w0.set(0);
        w0.set(1, 1, -1);
        w0.set(1,2,-1);
        SimpleMatrix w1 = mynet.getWeight(1);
        w1.set(1);
        w1.set(1, 1, -1);
        w1.set(3,1,-1);
        SimpleMatrix b0 = mynet.getBias(0);
        b0.set(0,0, -1);
        b0.set(1,0, 1);
        SimpleMatrix b1 = mynet.getBias(1);
        b1.set(1);
        b1.set(3,0, -1);
        
        
        //Creo una entrada para la red
        double[][] input = new double[][]{{1,2,-1}};
        SimpleMatrix x = new SimpleMatrix(input);
        x = x.transpose();
        
        //Calculo el resultado de la fase feedforward
        SimpleMatrix output = mynet.feedforward(x);
        output.print();
    }
    
    /**
     * Ejemplo de como regenerar los ficheros bin para carga rápida de la BD a partir
     * de la base de datos original MNIST
     * @throws IOException 
     */
    public static void regenerarBD_MNIST() throws IOException{
        MnistLoader myLoader = new MnistLoader();
        myLoader.generateEJMLBinFiles();
    }
    
}
