/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package p2_si;

import java.util.ArrayList;
import org.ejml.simple.SimpleMatrix;
import java.util.Random;
import org.ejml.equation.Equation;
import org.ejml.ops.CommonOps;

/**
 *
 * @author fidel
 */
public class NNetwork {
    
    public NNetwork(int[] layerSize){
            
        _rand = new Random();
        
        _numLayers = layerSize.length;
        _sizes = layerSize;
        
        //Genero las matrices de los bias para cada capa
        _biases = new ArrayList();
        for(int i=1; i<_numLayers; i++){
           _biases.add(SimpleMatrix.random(layerSize[i],1,-1,1,_rand)); 
        }
        
        //Y el de los pesos
        _weights = new ArrayList();
        for(int i=1; i<_numLayers; i++){
           _weights.add(SimpleMatrix.random(layerSize[i],layerSize[i-1],-1,1,_rand)); 
        }
        
    }
    
    public SimpleMatrix sigmoid(SimpleMatrix a){
        //return 1.0/(1.0+np.exp(-z))
        
        SimpleMatrix b=new SimpleMatrix(a);
        
        /*
        Más rápido pero menos intuitivo...
        
        CommonOps.changeSign(b.getMatrix());
        CommonOps.elementExp(b.getMatrix(),b.getMatrix());
        CommonOps.add(b.getMatrix(),1.0);
        CommonOps.elementPower(b.getMatrix(),-1,b.getMatrix());*/
        
        Equation eq = new Equation();
        eq.alias(a,"a",b,"b");
        eq.process("b=1.0/(1.0+exp(-a))");
        
        return b;
    }
    
    public SimpleMatrix feedforward(SimpleMatrix x){
        // sigmoid(w*x+b)
        
        SimpleMatrix w,b;
        SimpleMatrix y = new SimpleMatrix(x);
        
        SimpleMatrix r=new SimpleMatrix(_sizes[_numLayers-1],1);
        for(int i=0; i<_numLayers-1; i++){
            b = (SimpleMatrix) _biases.get(i);
            w = (SimpleMatrix) _weights.get(i);

            Equation eq = new Equation();
            eq.alias(b,"b",w,"w",y,"y",r,"r");
            eq.process("y = w*y+b");
            y = sigmoid(y);
 
        }
        return y;
    }
    
    public SimpleMatrix getWeight(int layer){
        return (SimpleMatrix) _weights.get(layer);
    }
    
    public SimpleMatrix getBias(int layer){
        return (SimpleMatrix) _biases.get(layer);
    }
    
    private final int _numLayers;
    private final int[] _sizes;
    private final ArrayList  _biases;
    private final ArrayList _weights;
    private Random _rand;
    
}
